package contract;


public class Timer {

	private int time;
/**
 * @author ARISTIDE KOLOKO KALEU
 * @return time
 */
	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}
	
	public void timeDecrease(){}
}

