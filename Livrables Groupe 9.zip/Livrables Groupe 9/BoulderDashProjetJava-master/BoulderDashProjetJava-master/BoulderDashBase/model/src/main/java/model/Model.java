package model;

public class Model {

}
