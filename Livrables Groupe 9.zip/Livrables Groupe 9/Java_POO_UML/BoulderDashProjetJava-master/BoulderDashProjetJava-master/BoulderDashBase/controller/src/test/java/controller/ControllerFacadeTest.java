/*
package controller;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import model.IModel;

public class ControllerFacadeTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	private IView view;
	private IModel model;

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testControllerFacade(final IView view, final IModel model) {
	        this.setView(view);
	        this.setModel(model);
	}

	@Test
	public final void testStart() {
		//fail("Not yet implemented");
	}

	public IView getView() {
		return view;
	}

	public void setView(IView view) {
		this.view = view;
	}

	public IModel getModel() {
		return model;
	}

	public void setModel(IModel model) {
		this.model = model;
	}

}

*/
