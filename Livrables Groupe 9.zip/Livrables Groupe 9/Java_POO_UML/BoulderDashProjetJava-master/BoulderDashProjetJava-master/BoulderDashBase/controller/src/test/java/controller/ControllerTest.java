
package controller;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ControllerTest {
 
	@BeforeClass 
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public final void testController() {
		
	}

	@Test
	public final void testKeyPressed() {
		
	}

	@Test
	public final void testKeyReleased() {
		
	}

	@Test
	public final void testKeyTyped() {
		
	}

}
