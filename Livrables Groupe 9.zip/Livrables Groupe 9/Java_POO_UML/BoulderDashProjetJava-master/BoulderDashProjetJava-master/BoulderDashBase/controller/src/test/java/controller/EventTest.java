package controller;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class EventTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testEvent() {
		
		
	}

	@Test
     public final void testGetGameLost() {
	/* boolean gameLost = false;
		return gameLost ;  */
	}  

	@Test
	public final void testGetGotDiamond() {
		
	}

	@Test
	public final void testGetDoorReach() {
		
	}

	@Test
	public final void testMovement() {
		
	}

	@Test
	public final void testMouvementRocher() {
		
	}

	@Test
	public final void testMouvementIA() {
		
	}

}


